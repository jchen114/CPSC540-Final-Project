#define WIN32_LEAN_AND_MEAN

#include <windows.h>		// The windows header file needs to be here...
#include <gl/gl.h>			// Header File For The OpenGL32 Library
#include <gl/glu.h>			// Header File For The GLu32 Library




