# order is:
# Position
# Orientation
# Velocity
# AngularVelocity

# Relative Orientation
# Relative Angular Velocity
#----------------

# Heading
0

# Root(pelvis)
0 1.037192 0
1 0 0 0
0 0 0
0 0 0

# pelvis_torso
#0.825335615 0.325996484 0.325996484 0.325996484
1 0 0 0
0 0 0

# lHip
1 0 0 0
0 0 0

# rHip
1 0 0 0
0 0 0

# torso_head
1 0 0 0
0 0 0

# lShoulder
1 0 0 0
0 0 0

# rShoulder
1 0 0 0
0 0 0

# lKnee
1 0 0 0
0 0 0

# rKnee
1 0 0 0
0 0 0

# lElbow
1 0 0 0
0 0 0

# rElbow
1 0 0 0
0 0 0

# lAnkle
1 0 0 0
0 0 0

# rAnkle
1 0 0 0
0 0 0

# lToeJoint
1 0 0 0
0 0 0

# rToeJoint
1 0 0 0
0 0 0

