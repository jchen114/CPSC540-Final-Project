#ifndef __GSL_MATRIX_H__
#define __GSL_MATRIX_H__


#include <gsl/matrix/gsl_matrix_double.h>


#endif /* __GSL_MATRIX_H__ */
