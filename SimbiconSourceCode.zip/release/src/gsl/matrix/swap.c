#include <gsl/matrix/gsl_matrix.h>
#include <gsl/vector/gsl_vector.h>
#include <stdlib.h>


#define BASE_DOUBLE
#include <gsl/templates_on.h>
#include <gsl/matrix/swap_source.c>
#include <gsl/templates_off.h>
#undef BASE_DOUBLE
