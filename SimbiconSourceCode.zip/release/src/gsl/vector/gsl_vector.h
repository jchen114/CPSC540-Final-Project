#ifndef __GSL_VECTOR_H__
#define __GSL_VECTOR_H__

#include <gsl/vector/gsl_vector_double.h>


#endif /* __GSL_VECTOR_H__ */
